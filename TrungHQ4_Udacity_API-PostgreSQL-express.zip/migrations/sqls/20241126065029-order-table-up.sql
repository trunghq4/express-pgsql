CREATE TABLE "order" (
    id SERIAL PRIMARY KEY,
    status INTEGER,
    user_id INTEGER
);