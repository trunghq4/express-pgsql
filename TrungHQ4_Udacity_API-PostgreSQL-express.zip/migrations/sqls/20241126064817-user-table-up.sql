CREATE TABLE "user" (
    id SERIAL PRIMARY KEY,
    firstName VARCHAR(150),
    lastName VARCHAR(150),
    password VARCHAR(255)
);